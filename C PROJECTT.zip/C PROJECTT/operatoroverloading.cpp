#include<iostream>
using namespace std;
class ABC{
	int a,b;
public:
	void get(){
		cin>>a>>b;
	}
	void put(){
		cout<<a<<endl<<b<<endl;
	}
	void operator ++(){
		a=++a;
		b=++b;
	}
	friend void operator --(ABC &);
};
void operator --(ABC &z)
{
	z.a=--z.a;
	z.b=--z.b;
}
main(){
	ABC ob;
	cout<<"enter values of a and b"<<endl;
	ob.get();
	cout<<"a and b="<<endl;
	ob.put();
	
	++ob;
	cout<<"After increment a and b="<<endl;
	ob.put();
	--ob;
	cout<<"After decrement a and b="<<endl;
	ob.put();
	
	system("pause");
}
