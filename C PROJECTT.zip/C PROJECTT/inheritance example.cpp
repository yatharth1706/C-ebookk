#include<iostream>
using namespace std;
class base{
	private:
		int base_a;
	protected:
		int base_b;
	public:
		void base_set(){
		cin>>base_a>>base_b;
		cout<<"----------base class---------------"<<endl;
		cout<<base_a<<endl<<base_b<<endl;	
		}
};
class derived:public base{
	private:
		int derived_a;
	protected:
		int derived_b;
	public:
		void derived_set(){
			cin>>derived_a>>derived_b;
			cout<<"----------derived class-------------"<<endl;
			cout<<derived_a<<endl<<derived_b<<endl;
		}
};
class c:protected base,public derived{
	public:
		void c_set();
};
main(){
	c c1;
	derived d;
//	c l;
cout<<"enter values of base class:"<<endl;

	c.base_set();
	enter
	c.derived_set();
	system("pause");
//	l.base_set();
}
