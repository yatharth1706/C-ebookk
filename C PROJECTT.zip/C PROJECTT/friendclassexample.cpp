#include<iostream>
using namespace std;

class student1
{
	friend class student2;
	private: int a;
	public:
		void getdata(){
			cout<<"enter the value of a:"<<endl;
			
			cin>>a;
		}
	};
	class student2
	{
		public: void display(student1 s1)
		{
		
			cout<<s1.a<<endl;
	}
	};
	main(){
		student1 s1;
		student2 s2;
		s1.getdata();
		s2.display(s1);
		system("pause");
	}
