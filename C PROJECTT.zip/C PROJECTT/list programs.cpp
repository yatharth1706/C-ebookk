#include<iostream>
#include<list>
using namespace std;

main(){
	int arr1[]={1,2,3,4};
	int arr2[5]={6,7,8,9};
	list <int> l1(arr1,arr1+4);
	list <int> l2(arr2,arr2+4);
	list <int>::iterator s=l2.begin();
	list <int>::iterator e=l2.end();
//	l2.pop_front();
//	l2.push_front(9);
//	l2.push_back(10);
//	l2.pop_back();
	
//	l2.pop_front();
	
	while(s!=e){
		cout<<*s<<endl;
		s++;
	}
	cout<<"------------------Back Inserter-----------"<<endl;
	copy(l1.begin(),l1.end(),back_inserter(l2));
	s=l2.begin();
	while(s!=e){
		cout<<*s<<endl;
		s++;
	}	
		cout<<"------------------Front Inserter-----------"<<endl;
		s=l2.begin();
		copy(l1.begin(),l1.end(),front_inserter(l2));
		while(s!=e){
			cout<<*s<<endl;
			s++;
		}
}
