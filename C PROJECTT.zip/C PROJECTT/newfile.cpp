#include<iostream>
using namespace std;
class YV{
	public:
		int a,b;
		void put(){
			cout <<a<<" "<<b<<endl;
		}
};
main(){
	YV A;
	int YV::*p;
	
	p=&YV::a;
	
	A.*p=10;
	A.b=20;
	A.put();
	system("pause");
	
}

