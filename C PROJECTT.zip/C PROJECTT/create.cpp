
#include<iostream>

using namespace std;
int main(){
cout<<"hahahahahha"<<endl;
}
