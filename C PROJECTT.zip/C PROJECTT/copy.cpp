#include<iostream>
#include<fstream>

using namespace std;
main(){
ifstream fin;
fin.open("classex.cpp");
ofstream fout;
fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
char ch;
while(!fin.eof()){
	fin.get(ch);
	fout<<ch;
}
fin.close();
return 0;

	
}
