#include<iostream>
#include<fstream>
using namespace std;

main(){
	string str;
	string ch;
	fstream fout;
	fout.open("create.cpp",ios::out);
	while(ch!=".")
	{
		while(ch!="."){
		
	getline(cin,ch);
	if(ch==".")
	{
	goto N;}
	else{
		fout<<ch<<endl;
	}
}}
N:
fout.close();
}







