#include<iostream>
using namespace std;
template <class T1,class T2>
class sample{
	T1 value1;
	T2 value2;
	public:
	sample(T1 x, T2 y)
	{
		value1=x;
		value2=y;
	}
	void sum();
};
template <class T1,class T2>
void sample <T1,T2> :: sum(){
	T2 value;
	value=value1+value2;
	cout<<"sum="<<value<<endl;
}


main(){
	sample <int,float>obj1(100,20.7);
	sample <float,int>obj2(12.4,10);
	
//	cout<<"enter two integer numbers="<<endl;
//	obj1.getdata();
	obj1.sum();
	
//	cout<<"enter two floating numbers="<<endl;
//	obj2.getdata();
	obj2.sum();
}
