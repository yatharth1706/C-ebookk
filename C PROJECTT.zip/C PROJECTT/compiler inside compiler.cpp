#include<iostream>
using namespace std;

main(){
	int a;
	cin>>a;
		
		switch(a){
			case 1:
				{
					system("start classex.exe");
					break;
				}
				default:
					{
						cout<<"invalid number"<<endl;
					}
		}
	
}
