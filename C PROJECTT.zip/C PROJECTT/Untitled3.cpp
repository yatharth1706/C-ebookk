#include<iostream>
#include<conio.h>
using namespace std;
void test(int x)
{
	try{
		if(x==1)
		throw x;
			else if(x==0) throw ('x');
			else if(x==-1) throw 1.0;
		else
			cout<<"value="<<x<<endl;;
	}
	
		catch(char c)
			{
				cout<<"caught a character"<<endl;
				}	
		catch(int m)
		{
			cout<<"caught an integer"<<endl;
			}	
		catch(double c)
		{
			cout<<"caught a double"<<endl;
			}	
			cout<<"end of try catch system"<<endl;

}

main()
{
cout<<"Testing Multiple Catches";
cout<<"x==1"<<endl;
test(1);
cout<<"x==0"<<endl;
test(0);
cout<<"x==-1"<<endl;
test(-1);
cout<<"x==2"<<endl;
test(2);
return 0;	
}
