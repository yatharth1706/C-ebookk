#include<iostream>
#include<fstream>
using namespace std;
main(){
	string name,name1;
	float cost,cost1;
	ofstream of;
	of.open("yash.txt");
	cout<<"enter name:";
	getline(cin,name);
//	cin.ignore();
	of<<name<<"\n";
//	cin.ignore();
	cout<<"enter cost";
	cin>>cost;
	of<<cost<<"\n";
	of.close();
	
	ifstream inf("yash.txt");
//	cin.ignore();
	getline(inf,name);
	inf>>cost;
	cout<<"\n item name"<<name;
	cout<<"\n item cost"<<cost;
	inf.close();
	
	system("pause");
	
}
