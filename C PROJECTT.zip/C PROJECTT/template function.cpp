#include<iostream>
using namespace std;
template <class T>
void swp(T &x, T &y)
{
	T temp=x;
	x=y;
	y=temp;
}

void fun(int m, int n, float a, float b){
	cout<<"m and n before swap"<<m<<" "<<n<<endl;
//	swap(m,n);
	swp(m,n);
	cout<<"m and n after swap"<<m<<" "<<n<<endl;
	
	cout<<"a and b before swap"<<a<<" "<<b<<endl;
	swp(a,b); 
	cout<<"a and b after swap"<<a<<" "<<b<<endl;
	
}
main(){
	fun(10,30,23.32,45.32);
	char a='A';
	char b='B';
	swp(a,b);
	cout<<a<<" "<<b<<endl;
	string A="hello";
	string B="bye";
	swp(A,B);
	cout<<A<<" "<<B<<endl;
	
	return 0;
}
