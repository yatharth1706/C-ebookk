#include<iostream>
#include<conio.h>
#include<process.h>
#include<windows.h>
using namespace std;
#include<fstream>


main(){
	const int n=130;
//	char line[n];
	system("color 31");
	Sleep(1000);
	system("color bc");
	Sleep(1000);
	system("color 0B");
	fstream  fin;
			fin.open("T23.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
//	fstream  fin;
//			fin.open("T23.txt");
//			char ch;
//			while(fin)
//			{	fin.get(ch);
//			cout<<ch;
//			}
//			fin.close();
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
 
  printf("\t\t\t\t\t\t\t\t   Name: Yatharth Verma\n\n");
  printf("\t\t\t\t\t\t\t\t   Roll No: 40\n\n");
 	 printf("\t\t\t\t\t\t\t\t  >>> PRESS ANY KEY TO CONTINUE <<<"); 
getch();
system("cls");
int a,b,c;
goto B;
B:
{
		
//	cout<<"\t\t\t\t\t\t\t\t\tC++ WORKBOOK"<<endl;
	
		cout<<"\t\t\t\t\t------------------------C++ WORKBOOK --------------------------"<<endl;
	cout<<"\n\n\n\n";
	cout<<"\t\t\t\t\t\t\t\t1. C++ Concepts."<<endl;
	cout<<"\t\t\t\t\t\t\t\t2. C++ Examples"<<endl;
	cout<<"\t\t\t\t\t\t\t\t3. Editor options"<<endl;
	cout<<"\t\t\t\t\t\t\t\t4. Exit"<<endl;
	}
	cin>>a;
	switch(a){
	case 3:{
		system("cls");
		cout<<"\t\t\t\t\t-------CHOOOSE ANY OPTION TO CHANGE BACKGROUDN AND FOREGROUND COLOR OF FRONT PAGE-----------\n\n\n\n"<<endl;
		cout<<"\t\t\t\t\t1. Blackish aqua"<<endl;
		cout<<"\t\t\t\t\t2. Reddish yellow"<<endl;
		cout<<"\t\t\t\t\t3. Whitish red"<<endl;
		cout<<"\t\t\t\t\t4. Reddish green"<<endl;
		cout<<"\t\t\t\t\t5. Grey aqua"<<endl;
		cout<<"\t\t\t\t\t6. Blue Yellow"<<endl;
		cout<<"\t\t\t\t\t7. Want to go back"<<endl;
		cin>>a;
		switch(a){
			case 1:{
				system("cls");
				system("color 0B");
				goto B;
				break;
			}
			case 2:{
				system("cls");
				system("color 4E");
				goto B;
					break;
			}
			case 3:{
				system("cls");
				system("color 7C");
				goto B;
				break;
			}
			case 4:{
				system("cls");
				system("color 4A");
				goto B;
				break;
			}
			case 5:{
				system("cls");
				system("color 8B");
				goto B;
				break;
			}
			case 6:{
				system("cls");
				system("color 1E");
				
				goto B;
				break;
			}
			case 7:{
				system("cls");
				goto B;
				break;
			}
			default:{
				cout<<"invalid number"<<endl;
				break;
			}
		}
		
		break;
	}
	case 4:{
		system("cls");
		cout<<"\t\t\t===============THANK YOU===================="<<endl;
		cout<<"\t\t\t\t\tSubmitted by: Yatharth"<<endl;
		cout<<"\t\t\t\t\tRoll No: 40"<<endl;
		cout<<"\t\t\t\t\tSection: K17TS"<<endl;
		system("exit");
		break;
	}
	case 1:
	{
	system("cls");
	A:
	system("color 0B");
	cout<<"\t\t\t\t\t\t\t\tList of C++ Concepts"<<endl;
	cout<<"\t\t\t\t\t\t\t\t(Press corrosponding number to learn that concept)"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t------------------------------------"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t------------------------------------"<<endl;
	cout<<"\t\t\t\t\t\t\t1. Arrays"<<endl;
	cout<<"\t\t\t\t\t\t\t2. Strings"<<endl;
	cout<<"\t\t\t\t\t\t\t3. Manipulated strings"<<endl;
	cout<<"\t\t\t\t\t\t\t4. Objects and Classes."<<endl;
	cout<<"\t\t\t\t\t\t\t5. C++ pointers"<<endl;
	cout<<"\t\t\t\t\t\t\t6. C++ constructors and Destructors"<<endl;
	cout<<"\t\t\t\t\t\t\t7. C++ overloading"<<endl;
	cout<<"\t\t\t\t\t\t\t8. Data Abstraction"<<endl;
	cout<<"\t\t\t\t\t\t\t9. Inheritance"<<endl;
	cout<<"\t\t\t\t\t\t\t10. Qualifiers and Storage Classes"<<endl;
	cout<<"\t\t\t\t\t\t\t11. Freind Function"<<endl;
	cout<<"\t\t\t\t\t\t\t12. Virtual Function"<<endl;
	cout<<"\t\t\t\t\t\t\t13. File Handling"<<endl;
	cout<<"\t\t\t\t\t\t\t14. Dynamic Memory Allocation"<<endl;
	cout<<"---------------------------"<<endl;
	cout<<"Press 0 to go back"<<endl;
	cout<<"Press corrosponding number to learn concept"<<endl;
	
	cin>>a;
	switch(a){
		case 0:{
			system("cls");
			goto B;
			break;
		}
		case 1:
			{
				cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\array.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;	
			}
		case 2:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\string.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 3:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\manistring.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 4:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\CLASS1.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 5:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\POINTERS.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 6:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\constructor and destructor.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 7:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\OVERLOADING.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 8:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\DATA ABSTRACTION.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 9:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\inheritance.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 10:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\QUALIFIERS.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		
		case 11:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\FRIEND.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 12:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\VIRTUAL FUNCTION.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 13:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\FILE HANDLING.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		case 14:
			{
			cout<<"---------------------------"<<endl;
			system("cls");
			fstream  fin;
			fin.open("notes\\DYNAMIC.txt");
			char ch;
			while(fin)
			{	fin.get(ch);
			cout<<ch;
			}
			fin.close();
			cout<<"press enter to go to back";
			getch();
			system("cls");
			goto A;
			break;
			
		}
		
						default:
						{
								cout<<"invalid number"<<endl;
//								system("cls");
//								goto A;
}
//break;
						}
					break;
				}
				case 2:
					{
						system("color 3f");
						
						
						system("cls");
						c:{
							cout<<"\t\t\t\t\t\t\t\t\tList of programs"<<endl;
						cout<<"\t\t\t\t\t\t\t\t\t--------------------"<<endl;
						cout<<"\t\t\t\t\t\t\t\t\t--------------------"<<endl;
						cout<<"\t\t\t\t\t\t\t\t1. C++ program to demonstrate implementation of Inheritance "<<endl;
						cout<<"\t\t\t\t\t\t\t\t2. C++ program to demonstrate single inheritance"<<endl;
						cout<<"\t\t\t\t\t\t\t\t3. C++ program to demonstrate multiple inheritance"<<endl;	
						cout<<"\t\t\t\t\t\t\t\t4. C++ program to demonstrate multilevel inheritance"<<endl;
						cout<<"\t\t\t\t\t\t\t\t5. C++ program to heirarchical inheritance"<<endl;
						cout<<"\t\t\t\t\t\t\t\t6. C++ program for operator overloading"<<endl;
						cout<<"\t\t\t\t\t\t\t\t7. C++ program for function overloading"<<endl;
						cout<<"\t\t\t\t\t\t\t\t8. C++ program for constructor inheritance"<<endl;
						cout<<"\t\t\t\t\t\t\t\t9. C++ program for file handling"<<endl;
						cout<<"\t\t\t\t\t\t\t\t10 C++ program for friend class example"<<endl;
						cout<<"\t\t\t\t\t\t\t\t11 C++ program for pointer to data member"<<endl;
						cout<<"\t\t\t\t\t\t\t\t------------------------------"<<endl;
						cout<<"Press 0 to go back"<<endl;
						cout<<"Press corrosponing number to see code"<<endl;
						cout<<"Press 12 to add a file/Compile a file"<<endl;}
						cin>>a;
						switch(a){
							case 12:{
								system("cls");
								cout<<"\t\t\t\t\t\t\t\t\t\t Write Your Code Here"<<"\n\n\n\n";
									fstream fout;
									fout.open("sample.cpp",ios::out|ios::in|ios::trunc);
									string ch;
									while(ch!=".")
									{
										
										
									getline(cin,ch);
									if(ch==".")
									{
									goto N;}
									else{
										fout<<ch<<endl;
									}
								}
								N:
								fout.close();
								system("pause");
								cout<<"press 0 to go back"<<endl;
								cout<<"press 1 to compile"<<endl;
								cin>>a;
								switch(a){
										case 0:{
			system("cls");
			goto B;
			break;
		}
									case 1:{
										system("g++ sample.cpp -o Sample");
										cout<<"press 0 to go back"<<endl;
										cout<<"press 1 to run the file"<<endl;
										cout<<"----------------------------"<<endl;
										cout<<"----------------------------"<<endl;
										cin>>a;
										switch(a){
										case 0:{
											system("pause");
											goto c;
											break;
										}
										case 1:{
											system("sample.exe");
											system("pause");
											cout<<"press 0 to go back"<<endl;
											cin>>a;
											switch(a){
												case 0:{
													system("cls");
													goto c;
													break;
												}
												default:{
													cout<<"invalid number"<<endl;
													break;
												}
											}	
											break;
										}
										default:{
											cout<<"invalid number"<<endl;
											break;
										}
								
										break;
									}}
									default:{
										cout<<"invalid number"<<endl;
										break;
									}
								}
								break;
							}
							case 0:
								{
									system("cls");
									goto B;
								}
							case 1:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("simpleinher.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start simpleinher.exe");
										system("cls");
										goto c;

										break;
									}
									case 2:{
										
										ifstream fin;
										fin.open("simpleinher.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										
										return 0;
										break;
									}
									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
								
								
							}
							case 2:{cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("simpleinher.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start simpleinher.exe");
										system("cls");
										goto c;
										
										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("simpleinher.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 3:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("multipleinher.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start multipleinher.exe");
										system("cls");
										goto c;
		
										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("simpleinher.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								
								break;
							}
							case 4:{
							cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("multilevelinh.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start multilevelinh.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("multilevelinh.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}	
								break;
							}
							case 5:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("heirarchi.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start heirarchi.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("heirarchi.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 6:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("operatoroverloading.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start operatoroverloading.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("operatoroverloading.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"succesffully copied"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 7:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("areafunctionoverloading.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start areafunctionoverloading.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("areafunctionoverloading.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 8:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("constructorinheritance.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start constructorinheritance.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("constructorinheritance.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"successfully copied to newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 9:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("filehandling.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start filehandling.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("filehandling.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							case 10:{cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("friendclassexample.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start friendclassexample.exe");
										system("cls");
										goto c;
										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("friendclassexample.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to Newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
							
					case 11:{
								cout<<"---------------------------"<<endl;
								system("cls");
								fstream  fin;
								fin.open("ptrd.cpp");
								char ch;
								while(fin)
								{	fin.get(ch);
									cout<<ch;
								}
								fin.close();		
								cout<<"1. execute this code"<<endl;
								cout<<"2. copy this source code to another file"<<endl;
								cout<<"3 want to go back"<<endl;
								cin>>a;
								switch(a){
									case 1:{
										system("start ptrd.exe");
										system("cls");
										goto c;

										break;
									}
																		case 2:{
										
										ifstream fin;
										fin.open("ptrd.cpp");
										ofstream fout;
										fout.open("newfile.cpp",ios::in|ios::out|ios::trunc);
										char ch;
										while(!fin.eof()){
											fin.get(ch);
											fout<<ch;
										}
										fin.close();
										cout<<"Successfully copied to newfile.cpp"<<endl;
										return 0;
										break;
									}

									case 3:{
										system("cls");
										goto B;
										break;
									}
									default:{
										cout<<"invalid number";
										break;
									}
								}
								break;
							}
					default:
						{
							cout<<"invalid number"<<endl;
						}
					}
				}}}
			
						
					
				
			
				
		




