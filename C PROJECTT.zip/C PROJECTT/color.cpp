#include<iostream>
using namespace std;
main(){
	system("color xy");
}
