#include<iostream>
#include<conio.h>
using namespace std;

main(){
	system("g++ classex.cpp");
	getch();
}
