#include<iostream>
using namespace std;

template <class T>
void display(T x){
	cout<<"Template display"<<x<<"\n";
}
void display(int x){
	cout<<"Explicit display"<<x<<"\n";
}

main(){
	
	display(100);
	display(56.78);
	display('a');
	return 0;
}
