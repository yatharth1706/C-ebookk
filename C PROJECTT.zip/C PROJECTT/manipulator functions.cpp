#include<iostream>
#include<iomanip>
using namespace std;
main(){
	float a=300,b=500;
	double c=b/a;
	cout<<setfill('^');
	cout<<setw(5)<<a<<setw(5)<<b<<endl;v
	cout<<setw(6)<<a<<setw(6)<<b<<endl;
	cout<<setfill('@');
	cout<<setw(7)<<a<<setw(7)<<b<<endl;
	cout<<setiosflags(ios::fixed)<<setiosflags(ios::showpoint);
	cout<<setprecision(3)<<c<<endl;
	cout<<setprecision(5)<<c<<endl;
}
