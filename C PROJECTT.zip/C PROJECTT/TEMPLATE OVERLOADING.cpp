#include<iostream>
using namespace std;

template <class T>
void display(T x){
	cout<<"Template display"<<x<<"\n";
}
void display(int x){
	cout<<"Explicit display"<<x<<"\n";
}
template <class T1,class T2>
void display(T2 y, T1 x){
	cout<<"parameters two display:"<<x<<" "<<y<<endl;
}
main(){
	
	display(100);
	display(56.78);
	display('a');
	display("hello",4);
	return 0;
}
