#include<iostream>
using namespace std;
void divide(int x,int y)
{
	cout<<"inside function"<<endl;
	try{
		if(y==0)
			throw y;
		else
			cout<<x/y<<endl;
	}
		catch(int a)
		{
			cout<<"caught int inside function"<<endl;
		throw;
		}
		
	
	cout<<"end of the function"<<endl;
}

int main(){
	cout<<"inside main."<<endl;
	try{
		divide(10,2);
		divide(10,0);
	}
	catch(int){
		cout<<"caught inside main"<<endl;
		
	}
	return 0;
	}

