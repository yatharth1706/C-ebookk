#include<iostream>
#include<fstream>
using namespace std;


main(){
	ofstream fout;
	fout.open("create.cpp");
	char ch;
	while(ch!='.')
	{
		cin>>ch;
		while(ch!='.')
		{
			fout<<ch;
		}
		
	}
	fout.close();
}
