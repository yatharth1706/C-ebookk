#include<iostream>
#include<vector>
using namespace std;
main(){
	int arr[]={1,2,3,4};
	vector <int> v(arr,arr+4);
	vector <int>::iterator iter=v.begin();
	vector <int>::iterator ter=v.end();
	
	v.push_back(22);
	while()
	
}
