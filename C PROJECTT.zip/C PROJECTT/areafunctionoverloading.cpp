#include<iostream>
using namespace std;
//void area(int);
void area(float,float);
void area(int,int);

main(){
	int r;
	float l,b;
	int base,height;
	cout<<"enter the radius of circle:";
	cin>>r;
	cout<<"enter the base and height of triangle:";
	cin>>base>>height;
	
	cout<<"enter the length and breadth of rectangle:";
	cin>>l>>b;
	cout<<"-------------------------------"<<endl;
	cout<<"-------------------------------"<<endl;
//	area(r);
	area(base,height);
	area(l,b);
	
	system("pause");
}

/*void area(int x)
{
	float z;
	z=3.14*x*x;
	cout<<"area of circle="<<z<<endl;
}*/
void area(float a,float b){
	float y;
	y=a*b;
	cout<<"area of rectangle="<<y<<endl;
}
void area(int t,int o)
{
	int r;
	r=(t*o)/2;
	cout<<"area of triangle="<<r<<endl;
	
}
