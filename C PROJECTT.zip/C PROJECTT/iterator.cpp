#include<vector>
#include<iostream>
#include<conio.h>
using namespace std;

main(){
	int arr[]={1,2,3,4};
	vector <int> v(arr,arr+4);
	vector <int>::iterator iter=v.begin();
	cout<<"first element of v="<<*iter<<endl;
	iter++;
	iter=v.end()-1;
	cout<<"last element of v="<<*iter<<endl;
//	getch();
vector <int>::iterator s=v.begin();
vector <int>::iterator e=v.end();
	while(s!=e){
		cout<<*s<<endl;
		s++;
	}
	getch();
	
}

