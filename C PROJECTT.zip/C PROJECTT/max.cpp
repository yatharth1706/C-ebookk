#include<iostream>
#include<vector>
using namespace std;
int max(vector<int>::iterator start,vector<int>::iterator stop){
	int m=*start;
	while(start!=stop)
	{
		if(*start>m)
		m=*start;
		++start;
	}
	return m;
}
main(){
	vector <int> v(3);
	v[0]=23;
	v[1]=12;
	v[2]=9;
//	v[0]=23;
	v.push_back(17);
	cout<<"max of v="<<max(v.begin(),v.end());
	
}
