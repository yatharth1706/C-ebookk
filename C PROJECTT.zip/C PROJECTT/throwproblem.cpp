#include<iostream>
using namespace std;
main(){
int a,b;
cout<<"Enter the values of a and b: ";
cin>>a>>b;

try{
	if(b!=0)
	{
		cout<<"results(a/b)="<<a/b<<endl
	}
	else{
		throw(b);
	}
}	
catch(int i){
	cout<<"exception caught b: "<<b<<endl;
}
cout<<"end";
return 0;
}
