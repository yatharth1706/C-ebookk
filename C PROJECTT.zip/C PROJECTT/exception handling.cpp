#include<iostream>
using namespace std;

void check(int x,int y){
	cout<<"we are inside the function:"<<endl;
	if((x-y)!=0)
	{
		int R=x-y;
		cout<<"Result="<<R;
	}
	else{
		throw(x-y);
	}
}
main(){
int a,b;
cout<<"Enter the values of a and b"<<endl;
cin>>a;
cin>>b;

double age;
cout<<endl<<"enter your age:";
cin>>age;

try{
	cout<<"we are inside the block."<<endl;
	check(a,b);
	
}
	catch(int i){
		cout<<"Exception caught"<<endl;
	}
try{
	if(age<0)
	throw(age);
	
	cout<<endl<<"Age = "<<age<<endl;
}
	catch(double j){
		cout<<"Exception caught Age is invalid:"<<j<<endl;
	}
	cout<<"END";
}
